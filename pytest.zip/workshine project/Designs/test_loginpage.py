import pytest
from playwright.sync_api import sync_playwright

def test_home_packages_login_enroll_buttons():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        context = browser.new_context()
        page = context.new_page()

        # Open the application
        page.goto("https://qa.workshine.com:8443/")
        page.wait_for_load_state("networkidle")

        # Check Home button
        home_btn = page.wait_for_selector("div.home-nav-items", state="visible")
        home_text = home_btn.inner_text().strip()
        home_color = home_btn.evaluate("el => window.getComputedStyle(el).color")
        if home_text == "Home" and home_color == "rgb(255, 255, 255)":
            print("✅ Home button name and color matched.")
        else:
            print(f"❌ Home button mismatch: text='{home_text}', color='{home_color}'")
            assert False, f"Home button mismatch: text='{home_text}', color='{home_color}'"

        # Check Packages button (next .home-nav-items)
        packages_btn = page.query_selector_all("div.home-nav-items")[1]
        packages_text = packages_btn.inner_text().strip()
        packages_color = packages_btn.evaluate("el => window.getComputedStyle(el).color")
        if packages_text == "Packages" and packages_color == "rgb(255, 255, 255)":
            print("✅ Packages button name and color matched.")
        else:
            print(f"❌ Packages button mismatch: text='{packages_text}', color='{packages_color}'")
            assert False, f"Packages button mismatch: text='{packages_text}', color='{packages_color}'"

        # Check Log in button
        login_btn = page.wait_for_selector(".elementor-widget-button .elementor-button", state="visible")
        login_text = login_btn.inner_text().strip().upper()
        login_bg_color = login_btn.evaluate("el => window.getComputedStyle(el).backgroundColor")
        login_font_size = login_btn.evaluate("el => window.getComputedStyle(el).fontSize")
        if login_text == "LOG IN" and login_bg_color == "rgb(255, 255, 255)" and login_font_size == "14px":
            print("✅ Log in button name, color, and size matched.")
        else:
            print(f"❌ Log in button mismatch: text='{login_text}', color='{login_bg_color}', size='{login_font_size}'")
            assert False, f"Log in button mismatch: text='{login_text}', color='{login_bg_color}', size='{login_font_size}'"

        # Check Enroll For Free button (next .elementor-button)
        enroll_btn = page.query_selector_all(".elementor-widget-button .elementor-button")[1]
        enroll_text = enroll_btn.inner_text().strip().upper()
        enroll_bg_color = enroll_btn.evaluate("el => window.getComputedStyle(el).backgroundColor")
        enroll_font_size = enroll_btn.evaluate("el => window.getComputedStyle(el).fontSize")
        if enroll_text == "ENROLL FOR FREE" and enroll_bg_color == "rgb(255, 255, 255)" and enroll_font_size == "14px":
            print("✅ Enroll For Free button name, color, and size matched.")
        else:
            print(f"❌ Enroll For Free button mismatch: text='{enroll_text}', color='{enroll_bg_color}', size='{enroll_font_size}'")
            assert False, f"Enroll For Free button mismatch: text='{enroll_text}', color='{enroll_bg_color}', size='{enroll_font_size}'"

        context.close()
        browser.close()