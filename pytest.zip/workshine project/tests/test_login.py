import asyncio
from playwright.async_api import async_playwright
from pages.login_page import LoginPage

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        page = await browser.new_page()

        # Instantiate Page Object
        login_page = LoginPage(page)

        # Step 1: Navigate
        entered_url = "https://qa.workshine.com:8443/"
        await page.goto(entered_url)
        await page.wait_for_load_state("networkidle")
        await login_page.check_redirection(entered_url)

        # Step 2: Click login
        await login_page.click_login_link()

        # Step 3: Fill credentials
        await login_page.fill_username("narayana.vasantavada+babu1@infyshine.com")
        await login_page.fill_password("INFY@123")

        # Step 4: Show password check
        await login_page.check_show_password("INFY@123")

        # Step 5: Click login
        await login_page.click_login_button()

        # Step 6: Final confirmation
        await page.wait_for_load_state("networkidle")
        print("Login successful. Page title:", await page.title())

        await browser.close()

if __name__ == "__main__":
    asyncio.run(main())