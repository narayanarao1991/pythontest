# -*- coding: utf-8 -*-
import pytest
from playwright.sync_api import sync_playwright

def test_timesheet_apply005():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        context = browser.new_context()
        page = context.new_page()

        # Go to Workshine login page
        page.goto("https://qa.workshine.com:8443/")
        page.wait_for_load_state("networkidle")

        # Click login button
        page.wait_for_selector("span.elementor-button-content-wrapper > span", state="visible")
        page.click("span.elementor-button-content-wrapper > span")

        # Enter email
        page.wait_for_selector("input[name='emailId']", state="visible")
        page.fill("input[name='emailId']", "narayana.vasantavada+7866@infyshine.com")

        # Enter password
        if page.is_visible("input[name='password']"):
            page.fill("input[name='password']", "INFY@123")
        else:
            page.fill("div.form-group.mb-3 > input.form-control", "INFY@123")

        # Click login
        page.wait_for_selector("button.loginButton.btn", state="visible")
        page.click("button.loginButton.btn")
        page.wait_for_load_state("networkidle")

        # Navigate to Timesheet menu (4th item)
        page.wait_for_selector("li:nth-of-type(4) .menuToggle > .menuToggle", state="visible")
        page.click("li:nth-of-type(4) .menuToggle > .menuToggle")

        # Edit 5th row
        page.wait_for_selector("tr:nth-of-type(3) .edit", state="visible")
        page.click("tr:nth-of-type(3) .edit")

        # Add more
        page.wait_for_selector("button.addMoreBtn.btn", state="visible")
        page.click("button.addMoreBtn.btn")

        # Select project
        page.wait_for_selector("[data-value]", state="visible")
        page.click("[data-value]")
        page.wait_for_selector("#react-select-3-option-1", state="visible")
        page.click("#react-select-3-option-1")

        # Fill project input
        page.wait_for_selector("#react-select-3-input", state="visible")
        page.fill("#react-select-3-input", "Food products")

        # Cancel
        page.wait_for_selector("button:nth-of-type(2)", state="visible")
        page.click("button:nth-of-type(2)")

        # Confirm delete
        page.wait_for_selector("div.modal-content > div.btnCenter.mb-3 > button.Button.btn.btn-addbtn", state="visible")
        page.click("div.modal-content > div.btnCenter.mb-3 > button.Button.btn.btn-addbtn")

        # Close browser
        browser.close()
