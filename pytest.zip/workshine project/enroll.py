# -*- coding: utf-8 -*-
import pytest
from playwright.sync_api import sync_playwright

def test_enroll_user():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        context = browser.new_context()
        page = context.new_page()

        try:
            # Go to Workshine enroll page
            page.goto("https://dev.workshine.com:8443/", timeout=60000)
            page.wait_for_load_state("networkidle", timeout=60000)

            # Click Enroll button
            page.wait_for_selector("span:has-text('Enroll For Free')", state="visible", timeout=60000)
            page.click("span:has-text('Enroll For Free')", timeout=60000)

            # Click package selection buttons
            page.wait_for_selector("button.no-hover-effect.btn", state="visible", timeout=60000)
            page.click("button.no-hover-effect.btn", timeout=60000)
            page.click("button.no-hover-effect.btn", timeout=60000)
            page.wait_for_selector("div.packeageSlectionFooter2.col-sm-6 > button.btn", state="visible", timeout=60000)
            page.click("div.packeageSlectionFooter2.col-sm-6 > button.btn", timeout=60000)

            # Fill form fields
            page.wait_for_selector("#formGroupToDate", state="visible", timeout=60000)
            page.click("#formGroupToDate", timeout=60000)
            page.fill("#formGroupToDate", "Travel001", timeout=60000)
            page.fill("input[name='website']", "Travel001@gmail.com", timeout=60000)

            # Foundation date picker
            page.click("input[name='foundationDate']", timeout=60000)
            page.wait_for_selector("button.ant-picker-year-btn", state="visible", timeout=60000)
            page.click("button.ant-picker-year-btn", timeout=60000)
            page.wait_for_selector("td.ant-picker-cell.ant-picker-cell-in-view > div.ant-picker-cell-inner", state="visible", timeout=60000)
            page.click("td.ant-picker-cell.ant-picker-cell-in-view > div.ant-picker-cell-inner", timeout=60000)
            page.wait_for_selector("td.ant-picker-cell.ant-picker-cell-start.ant-picker-cell-in-view > div.ant-picker-cell-inner", state="visible", timeout=60000)
            page.click("td.ant-picker-cell.ant-picker-cell-start.ant-picker-cell-in-view > div.ant-picker-cell-inner", timeout=60000)

            # Select from dropdown
            page.wait_for_selector("[data-value]", state="visible", timeout=60000)
            page.click("[data-value]", timeout=60000)
            page.wait_for_selector("#react-select-2-option-111", state="visible", timeout=60000)
            page.click("#react-select-2-option-111", timeout=60000)

            # Address fields
            page.fill("input[name='address1']", "mainroad", timeout=60000)
            page.fill("input[name='address2']", "sideroad", timeout=60000)
            page.fill("input[name='city']", "Gudiwadas", timeout=60000)

            # State dropdown
            page.wait_for_selector("#react-select-3-input", state="visible", timeout=60000)
            page.click("#react-select-3-input", timeout=60000)
            page.fill("#react-select-3-input", "Andhra Pradesh", timeout=60000)
            page.keyboard.press("Enter")

            # Zip code
            page.fill("input[name='zipCode']", "521301", timeout=60000)

            # User details
            page.fill("input[name='firstName']", "raj", timeout=60000)
            page.fill("input[name='lastName']", "a1", timeout=60000)
            page.fill("input[name='email']", "narayana.vasantavada+raj1@gmail.com", timeout=60000)
            page.fill("input[name='alternateEmail']", "gjhghg@gmail.com", timeout=60000)
            page.fill("input[name='phoneNumber']", "8752031457", timeout=60000)

            # Captcha extraction (Playwright version)
            captcha_chars = page.query_selector_all(".captcha-display span")
            captcha_text = ""
            for ch in captcha_chars:
                if ch:
                    captcha_text += ch.inner_text()
            page.fill("input[name='captcha']", captcha_text, timeout=60000)

            # Checkbox
            page.click("input[type='checkbox']", timeout=60000)

            # Submit
            page.wait_for_selector("button.Button.btn.btn-addbtn", state="visible", timeout=60000)
            page.click("button.Button.btn.btn-addbtn", timeout=60000)

            # Confirmation
            page.wait_for_selector("button.btn.btn-conformationbtn", state="visible", timeout=60000)
            page.click("button.btn.btn-conformationbtn", timeout=60000)

            # Debugging: Take a screenshot of the dropdown state
            page.screenshot(path="debug_state_dropdown.png")

        except Exception as e:
            page.screenshot(path="error_enroll.png")
            print(f"Test failed: {e}")
            assert False, f"Test failed: {e}"

        finally:
            context.close()
            browser.close()
