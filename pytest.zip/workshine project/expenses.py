# -*- coding: utf-8 -*-
import time
from playwright.sync_api import sync_playwright, expect

def test_expenses_python():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)  # Set headless=True for no UI
        context = browser.new_context()
        page = context.new_page()

        # Open QA site
        page.goto("https://qa.workshine.com:8443/")
        time.sleep(2)

        # Login
        page.click("a.elementor-button.elementor-size-sm.elementor-animation-shrink")
        time.sleep(1)
        page.fill("input[name='emailId']", "NARAYANA.VASANTAVADA+7865@infyshine.com")
        time.sleep(1)
        page.fill("div.form-group.mb-3 > input.form-control", "INFY@123")
        time.sleep(1)
        page.click("button.loginButton.btn")
        time.sleep(2)

        # Navigate to Expenses module
        page.click("li:nth-of-type(3) .menuToggle > .menuToggle")
        time.sleep(1)
        page.click("div.addIcon")
        time.sleep(2)

        # Fill start date
        page.click("input[name='startDate']")
        time.sleep(1)
        page.wait_for_selector("tr:nth-of-type(2) > td:nth-of-type(2) > .ant-picker-cell-inner", timeout=5000)
        page.click("tr:nth-of-type(2) > td:nth-of-type(2) > .ant-picker-cell-inner")
        time.sleep(1)

        # Fill end date
        page.click("input[name='endDate']")
        time.sleep(1)
        page.wait_for_selector("html body div:nth-of-type(4) table tbody tr:nth-of-type(3) td:nth-of-type(2) div", timeout=5000)
        page.click("html body div:nth-of-type(4) table tbody tr:nth-of-type(3) td:nth-of-type(2) div")
        time.sleep(1)

        # Fill Branch
        page.click("#formGroupBranch")
        page.fill("#formGroupBranch", "sfsdfsdfds")
        time.sleep(1)
         
        # Click on add icon
        page.click("div.addIcon")
        time.sleep(2)

        # Select dropdown values
        page.click("svg.css-8mmkcg")
        time.sleep(1)
        page.click("#react-select-3-option-0")
        time.sleep(1)
        #page.click("div.css-t3ipsp-control > div.css-hlgwow > div.css-19bb58m")
        #time.sleep(1)
        #page.click("#react-select-4-option-0")
        #time.sleep(1)
        

         # Small date picker click
        page.locator("div.ant-picker.ant-picker-sm > div.ant-picker-input").click()
        page.locator(
        "html > body:nth-of-type(1) > div:nth-of-type(7) > div:nth-of-type(1) > div:nth-of-type(1) > "
        "div:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(1) > div:nth-of-type(2) > "
        "table:nth-of-type(1) > tbody:nth-of-type(1) > tr:nth-of-type(2) > td:nth-of-type(4) > "
         "div:nth-of-type(1)"
         ).click()

# Category dropdown
       # page.locator("div.css-15lsz6c-indicatorContainer > svg.css-8mmkcg").click()

# Another dropdown
       # page.locator("div.css-t3ipsp-control > div.css-hlgwow > div.css-19bb58m").click()
       # page.locator("div.css-t3ipsp-control > div.css-1wy0on6 > div").click()

# Select option
        #page.locator("#react-select-7-option-0").click()

# Amount field
       # page.locator("input[name='submittedAmount']").click()
       # page.locator("input[name='submittedAmount']").fill("20")

        # Select date picker small
       # page.click("div.ant-picker.ant-picker-sm.ant-picker-focused > div.ant-picker-input > input")
       # time.sleep(1)
       # page.wait_for_selector("html body div:nth-of-type(7) table tbody tr:nth-of-type(2) td:nth-of-type(3) div", timeout=5000)
       # page.click("html body div:nth-of-type(7) table tbody tr:nth-of-type(2) td:nth-of-type(3) div",timeout=8000)
       # time.sleep(1)

        # Select category using native select
       # page.select_option("select[name='category']", "Food")  # or "Accommodation", "Travel"
       # time.sleep(1)

        # Amount
       # page.fill("input[name='submittedAmount']", "20")
       # time.sleep(1)

    # Wait for currency dropdown to be visible, then click
        page.click("(//div[contains(@class,'css-1xc3v61-indicatorContainer')]/svg[contains(@class,'css-8mmkcg')])[3]", timeout=60000)  # Currency
        page.click("#react-select-10-option-0", timeout=60000)  # Select first currency
    # Select first currency option
        page.click("#react-select-10-option-0", timeout=60000)
    # Enter amount
        page.click("input[name='submittedAmount']", timeout=60000)
        page.fill("input[name='submittedAmount']", "30", timeout=60000)
    # Click remarks field
        page.click("input[name='remarks']", timeout=60000)

    # Add record
        page.click("button.Button.btn.btn-addbtn", timeout=60000)
        time.sleep(2)

        # Edit record
        page.click("i.fa-solid.fa-file-pen.fa-lg.edit")
        time.sleep(1)
        page.click(".btnCenter > button:nth-of-type(2)")
        time.sleep(1)
        page.click("div.modal-content > div.btnCenter.mb-4 > button.Button.btn.btn-addbtn")
        time.sleep(2)
        
        # Close toast
        page.click("button.Toastify__close-button.Toastify__close-button--light > svg")
        time.sleep(1)

        # Logout
        page.click("p.img")
        time.sleep(1)
        page.click("p:nth-of-type(3) .brand-text")
        time.sleep(2)

        # Login again for approval
        page.click("a.elementor-button.elementor-size-sm.elementor-animation-shrink")
        time.sleep(1)
        page.fill("input[name='emailId']", "narayana.vasantavada+7863@infyshine.com")
        time.sleep(1)
        page.click("div.form-group.mb-3 > input.form-control")
        time.sleep(1)
        page.click("path:nth-of-type(2)")
        time.sleep(1)
        page.click("button.loginButton.btn")
        time.sleep(2)

        # Approve expense
        page.click("div:nth-of-type(3) .menuToggle")
        time.sleep(1)
        page.click(".show li:nth-of-type(2) .pathName")
        time.sleep(1)
        page.click("div.text-center.actionsWidth > button.btn")
        time.sleep(1)
        page.fill("input[name='approvedRemarks']", "fsdfsdfsf")
        time.sleep(1)
        page.click("button.Button.btn.btn-addbtn")
        time.sleep(1)
        page.click("div.delbtn > button.Button.btn.btn-addbtn")
        time.sleep(2)

        # Logout
        page.click("button.Toastify__close-button.Toastify__close-button--light > svg > path")
        time.sleep(1)
        page.click("p:nth-of-type(3) .brand-text")
        time.sleep(2)

        # Login for reimbursement
        page.click("a.elementor-button.elementor-size-sm.elementor-animation-shrink")
        time.sleep(1)
        page.fill("input[name='emailId']", "narayana.vasantavada+7861@infyshine.com")
        time.sleep(1)
        page.click("svg")
        time.sleep(1)
        page.click("button.loginButton.btn")
        time.sleep(2)

        # Reimburse
        page.click("div:nth-of-type(4) .menuToggle")
        time.sleep(1)
        page.click(".show li:nth-of-type(3) .pathName")
        time.sleep(1)
        page.click("i.fa-solid.fa-file-pen.fa-lg.edit")
        time.sleep(1)
        page.fill("input[name='reimbursedRemarks']", "tertret")
        time.sleep(1)
        page.click("button.Button.btn.btn-addbtn")
        time.sleep(1)
        page.click("div.delbtn > button.Button.btn.btn-addbtn")
        time.sleep(2)

        # Close browser
        context.close()
        browser.close()

if __name__ == "__main__":
    test_expenses_python()
