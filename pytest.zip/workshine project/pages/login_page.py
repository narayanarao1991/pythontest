# pages/login_page.py
class LoginPage:
    def __init__(self, page):
        self.page = page
        self.login_link = 'a.elementor-button'
        self.username_input = 'input[name="emailId"]'
        self.password_input = 'input[type="password"]'
        self.show_password_icon = 'span.showPassword'
        self.login_button = 'button.loginButton'

    async def check_redirection(self, entered_url):
        current_url = self.page.url
        print(f"Entered URL: {entered_url}")
        print(f"Current URL: {current_url}")
        assert entered_url == current_url, "Redirection occurred."

    async def click_login_link(self):
        login_link = await self.page.query_selector(self.login_link)
        text = await login_link.inner_text()
        color = await login_link.evaluate("el => window.getComputedStyle(el).backgroundColor")
        assert text.strip().upper() == "LOG IN", "Log in text mismatch"
        assert color in ["rgb(255, 255, 255)", "rgb(105, 114, 125)"], "Log in color mismatch"
        await login_link.click()

    async def fill_username(self, username):
        value = await self.page.get_attribute(self.username_input, "value")
        assert not value, "Username field not empty"
        await self.page.fill(self.username_input, username)

    async def fill_password(self, password):
        value = await self.page.get_attribute(self.password_input, "value")
        assert not value, "Password field not empty"
        await self.page.fill(self.password_input, password)

    async def check_show_password(self, password):
        await self.page.click(self.show_password_icon)
        text_inputs = await self.page.query_selector_all('input[type="text"]')
        match = False
        for inp in text_inputs:
            val = await inp.get_attribute("value")
            if val == password:
                match = True
                break
        assert match, "Visible password mismatch"

    async def click_login_button(self):
        btn = await self.page.query_selector(self.login_button)
        text = await btn.inner_text()
        color = await btn.evaluate("el => window.getComputedStyle(el).backgroundColor")
        assert text.strip() == "Login", "Login button text mismatch"
        assert color == "rgb(0, 92, 185)", "Login button color mismatch"
        await btn.click()
