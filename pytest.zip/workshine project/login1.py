import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        page = await browser.new_page()

        # 1. Go to login page
        entered_url = "https://qa.workshine.com:8443/"
        await page.goto(entered_url)
        await page.wait_for_load_state("networkidle")
        current_url = page.url
        print(f"Entered URL: {entered_url}")
        print(f"Current URL: {current_url}")

        # 2. Check for redirection
        if entered_url != current_url:
            print("Error: Redirection occurred.")
            assert False, "Redirection occurred."

        # 3. Check and click "Log in" button (name and color)
        login_link = await page.query_selector('a.elementor-button')
        link_text = await login_link.inner_text()
        link_color = await login_link.evaluate("el => window.getComputedStyle(el).backgroundColor")
        # Make text comparison case-insensitive and allow both colors
        expected_text = "LOG IN"
        allowed_colors = ["rgb(255, 255, 255)", "rgb(105, 114, 125)"]
        if link_text.strip().upper() != expected_text or link_color not in allowed_colors:
            print(f"Error: Log in link name or color mismatch. Found text='{link_text}', color='{link_color}'")
            assert False, "Log in link name or color mismatch."
        print("Log in link name and color match. Proceeding to click.")
        await login_link.click()

        # 4. Check username field is empty, then enter username
        username_value = await page.get_attribute('input[name="emailId"]', 'value')
        if username_value:
            print("Error: Username field not empty before entry.")
            assert False, "Username field not empty before entry."
        await page.fill('input[name="emailId"]', "narayana.vasantavada+babu1@infyshine.com")

        # 5. Check password field is empty, then enter password
        password_value = await page.get_attribute('input[type="password"]', 'value1')
        if password_value:
            print("Error: Password field not empty before entry.")
            assert False, "Password field not empty before entry."
        entered_password = "INFY@123"
        await page.fill('input[type="password"]', "INFY@123")

        # 6. Click show/hide password icon and verify visible password
        await page.click('span.showPassword')
        # Find all input[type="text"] fields after show/hide
        text_inputs = await page.query_selector_all('input[type="text"]')
        visible_password = None
        for inp in text_inputs:
            val = await inp.get_attribute('value')
            if val == entered_password:
                visible_password = val
                break
        if visible_password is None:
            print(f"Error: Entered password and visible password do not match. Entered='{entered_password}'")
            assert False, "Entered password and visible password do not match."
        print("Entered password and visible password match.")

        # 7. Check login button name and color, then click
        login_btn = await page.query_selector('button.loginButton')
        btn_text = await login_btn.inner_text()
        btn_color = await login_btn.evaluate("el => window.getComputedStyle(el).backgroundColor")
        if btn_text.strip() != "Login" or btn_color != "rgb(0, 92, 185)":
            print(f"Error: Login button name or color mismatch. Found text='{btn_text}', color='{btn_color}'")
            assert False, "Login button name or color mismatch."
        await login_btn.click()

        # 8. Wait for login to complete and print page title
        await page.wait_for_load_state('networkidle')
        print("Login successful. Page title:", await page.title())
        await browser.close()

if __name__ == "__main__":
    asyncio.run(main())