# test_leave_apply.py

import pytest
import asyncio
from playwright.async_api import async_playwright

@pytest.mark.asyncio
async def test_leave_apply():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context()
        page = await context.new_page()

        try:
            # Step 1: Open WorkShine URL
            entered_url = "https://qa.workshine.com:8443/"
            await page.goto(entered_url, timeout=60000)
            await page.wait_for_load_state("networkidle", timeout=60000)
            current_url = page.url
            print(f"Entered URL: {entered_url}")
            print(f"Current URL: {current_url}")

            # 3. Check and click "Log in" button (name and color)
            login_link = await page.query_selector('a.elementor-button')
            if not login_link:
                print("Error: Log in link not found.")
                await page.screenshot(path="error_login_link.png")
                assert False, "Log in link not found."
            link_text = await login_link.inner_text()
            link_color = await login_link.evaluate("el => window.getComputedStyle(el).backgroundColor")
            expected_text = "LOG IN"
            allowed_colors = ["rgb(255, 255, 255)", "rgb(105, 114, 125)"]
            if link_text.strip().upper() != expected_text or link_color not in allowed_colors:
                print(f"Error: Log in link name or color mismatch. Found text='{link_text}', color='{link_color}'")
                await page.screenshot(path="error_login_link_color.png")
                assert False, "Log in link name or color mismatch."
            print("Log in link name and color match. Proceeding to click.")
            await login_link.click(timeout=60000)

            # 4. Check username field is empty, then enter username
            username_value = await page.get_attribute('input[name="emailId"]', 'value')
            if username_value:
                print("Error: Username field not empty before entry.")
                await page.screenshot(path="error_username_not_empty.png")
                assert False, "Username field not empty before entry."
            await page.fill('input[name="emailId"]', "narayana.vasantavada+7865@infyshine.com", timeout=60000)

            # 5. Check password field is empty, then enter password
            password_value = await page.get_attribute('input[type="password"]', 'value')
            if password_value:
                print("Error: Password field not empty before entry.")
                await page.screenshot(path="error_password_not_empty.png")
                assert False, "Password field not empty before entry."
            await page.fill('input[type="password"]', "INFY@123", timeout=60000)

            # 7. Check login button name and color, then click
            login_btn = await page.query_selector('button.loginButton')
            if not login_btn:
                print("Error: Login button not found.")
                await page.screenshot(path="error_login_btn.png")
                assert False, "Login button not found."
            btn_text = await login_btn.inner_text()
            btn_color = await login_btn.evaluate("el => window.getComputedStyle(el).backgroundColor")
            if btn_text.strip() != "Login" or btn_color != "rgb(0, 92, 185)":
                print(f"Error: Login button name or color mismatch. Found text='{btn_text}', color='{btn_color}'")
                await page.screenshot(path="error_login_btn_color.png")
                assert False, "Login button name or color mismatch."
            await login_btn.click(timeout=60000)

            # Step 2: Click the hamburger/menu icon
            await page.click("span.menuToggle > span.menuToggle", timeout=100000)

            # Step 3: Click Add Icon
            await page.click("div.addIcon", timeout=60000)

            # Step 4: Select Leave Type dropdown
            # Open the dropdown before selecting the option
            await page.click("div.css-8mmkcg-indicatorContainer > svg.css-8mmkcg", timeout=60000)
            await page.click("svg.css-8mmkcg", timeout=60000)
            await page.click("#react-select-3-option-1", timeout=60000)

            # Step 5: Select From Date
            await page.click("input[name='fromDate']", timeout=60000)
            await page.click("tr:nth-of-type(4) > td:nth-of-type(2) > .ant-picker-cell-inner", timeout=60000)

            # Step 6: Click Save/Add button
            await page.click("button.Button.btn.btn-addbtn", timeout=60000)

            # Step 7: Edit a record
            await page.click("i.fa-solid.fa-file-pen.fa-lg.edit", timeout=60000)
            await page.click("u", timeout=60000)
            await page.click("button.btn-close", timeout=60000)

            # Step 8: View record
            await page.click("span > a > u", timeout=60000)
            await page.click("button.btn-close", timeout=60000)

            # Step 9: Cancel the leave
            await page.click("button:nth-of-type(2)", timeout=60000)

            # Step 10: Delete the leave
            await page.click("div.delbtn > button.Button.btn.btn-addbtn", timeout=60000)

            # Step 11: Close Toast notification
            await page.click("button.Toastify__close-button.Toastify__close-button--light > svg > path", timeout=60000)

            # Step 12: Click logout (off image)
            await page.click("img[alt='off']", timeout=60000)

            # Step 13: Enter invalid To Date
            await page.click("#formGroupToDate", timeout=60000)
            await page.fill("#formGroupToDate", "fsdfsd", timeout=60000)
            await page.click("button.Button.btn.btn-addbtn", timeout=60000)
            await page.click("button.Toastify__close-button.Toastify__close-button--light > svg", timeout=60000)

        except Exception as e:
            await page.screenshot(path="error_leave_apply.png")
            print(f"Test failed: {e}")
            assert False, f"Test failed: {e}"
        finally:
            await context.close()
            await browser.close()

# Run the test
asyncio.run(test_leave_apply())
