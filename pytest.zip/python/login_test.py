# import pytest
# from playwright.sync_api import sync_playwright

# @pytest.fixture(scope="function")
# def browser():
#     with sync_playwright() as p:
#         browser = p.chromium.launch(headless=False)
#         context = browser.new_context()
#         page = context.new_page()
#         yield page
#         context.close()
#         browser.close()

# def test_login(browser):
#     # Open the target URL
#     browser.goto("https://qa.workshine.com:8443/")
#     # Click the login button
#     browser.click("a.elementor-button.elementor-size-sm.elementor-animation-shrink")
#     # Clear and enter email
#     browser.fill("input[name='emailId']", "narayana.vasantavada+7861@infyshine.com")
#     # Click the email field (if needed)
#     browser.click("input[name='emailId']")
#     # Click the third image (as per selector)
#     browser.click("img:nth-of-type(3)")

import asyncio
from playwright.async_api import async_playwright

async def run():
    async with async_playwright() as p:
        print("Launching browser...")
        browser = await p.chromium.launch(headless=False)  # Set headless to False to see the browser
        page = await browser.new_page()
        await page.goto("https://qa.workshine.com:8443/")
        print("Page loaded:", await page.title())
        await page.screenshot(path="screenshot.png")  # Optional: capture screenshot
        await browser.close()
        print("Test completed.")

asyncio.run(run())

